#ifndef MYAPP_GSENSOR_H_
#define MYAPP_GSENSOR_H_

#include <stdbool.h>
#include <stdint.h>

#include "socal/hps.h"
#include "hps_0.h"

#define assert(e) ((e) ? (void)0 : printf("Error in %s, Line : %d\r\n", __FILE__, __LINE__))

// |=============|==========|==============|==========|
// | Signal Name | HPS GPIO | Register/bit | Function |
// |=============|==========|==============|==========|
// |   HPS_LED   |  GPIO53  |   GPIO1[24]  |    I/O   |
// |=============|==========|==============|==========|
#define HPS_LED_IDX        (ALT_GPIO_1BIT_53)                      // GPIO53
#define HPS_LED_PORT       (alt_gpio_bit_to_pid(HPS_LED_IDX))      // ALT_GPIO_PORTB
#define HPS_LED_PORT_BIT   (alt_gpio_bit_to_port_pin(HPS_LED_IDX)) // 24 (from GPIO1[24])
#define HPS_LED_MASK       (1 << HPS_LED_PORT_BIT)

// |=============|==========|==============|==========|
// | Signal Name | HPS GPIO | Register/bit | Function |
// |=============|==========|==============|==========|
// |  HPS_KEY_N  |  GPIO54  |   GPIO1[25]  |    I/O   |
// |=============|==========|==============|==========|
#define HPS_KEY_N_IDX      (ALT_GPIO_1BIT_54)                        // GPIO54
#define HPS_KEY_N_PORT     (alt_gpio_bit_to_pid(HPS_KEY_N_IDX))      // ALT_GPIO_PORTB
#define HPS_KEY_N_PORT_BIT (alt_gpio_bit_to_port_pin(HPS_KEY_N_IDX)) // 25 (from GPIO1[25])
#define HPS_KEY_N_MASK     (1 << HPS_KEY_N_PORT_BIT)

void *fpga_leds = ALT_LWFPGASLVS_ADDR + LED_PIO_BASE;
void *fpga_buttons = ALT_LWFPGASLVS_ADDR + BUTTON_PIO_BASE;
void *fpga_pio_0 = ALT_LWFPGASLVS_ADDR + PIO_0_BASE;
void *fpga_switches = ALT_LWFPGASLVS_ADDR + DIPSW_PIO_BASE;

ALT_I2C_DEV_t i2c_dev;

void button_isr_callback (uint32_t icciar, void *context);
void sw_isr_callback (uint32_t icciar, void *context);

void timer_isr_callback (uint32_t icciar, void *context);
void setup_hps_interrupt();
void setup_hps_timer();
void setup_hps_gpio();
void setup_hps_i2c();
void setup_fpga_leds();
void delay_us(uint32_t us);
void handle_hps_led();
void handle_fpga_leds();
int handle_gsensor();
void handle_fpga_buttons();
void print_on_leds();
void read_switches();
void evaluation1_leds();
int current_switch=0;
// Timer to be used
#define GPT_TIMER_ID    ALT_GPT_CPU_PRIVATE_TMR
#define GPT_TIMER_IRQ   ALT_INT_INTERRUPT_PPI_TIMER_PRIVATE

// IRQ for the 2 buttons
#define GPT_BUTTON_IRQ   ALT_INT_INTERRUPT_F2S_FPGA_IRQ0 + BUTTON_PIO_IRQ
#define GPT_SW_IRQ   ALT_INT_INTERRUPT_F2S_FPGA_IRQ0 + DIPSW_PIO_IRQ


#endif
