#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "alt_i2c.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "hwlib.h"
#include "ADXL345.h"

// api for register access
bool ADXL345_REG_WRITE(ALT_I2C_DEV_t *i2c_dev, uint8_t address, uint8_t value);
bool ADXL345_REG_READ(ALT_I2C_DEV_t *i2c_dev, uint8_t address,uint8_t *value);
bool ADXL345_REG_MULTI_READ(ALT_I2C_DEV_t *i2c_dev, uint8_t readaddr,uint8_t readdata[],uint8_t len);



#define DATA_READY_TIMEOUT  (alt_ticks_per_second()/3)


bool ADXL345_REG_WRITE(ALT_I2C_DEV_t *i2c_dev, uint8_t address, uint8_t value){
    bool bSuccess = false;
    uint8_t szValue[2];
    
    szValue[0] = address;
    szValue[1] = value;
    
    if (alt_i2c_master_transmit(i2c_dev, &szValue, sizeof(szValue), false, true) == ALT_E_SUCCESS)
        bSuccess = true;
    return bSuccess;
}

bool ADXL345_REG_READ(ALT_I2C_DEV_t *i2c_dev, uint8_t address,uint8_t *value){
    bool bSuccess = false;
    uint8_t Value;
    
    if (alt_i2c_issue_write(i2c_dev, address, false, false) == ALT_E_SUCCESS) {
        if (alt_i2c_master_receive(i2c_dev, &Value, 1, false, true) == ALT_E_SUCCESS) {
            *value = Value;
            bSuccess = true;
        }
    }
    return bSuccess;
}

bool ADXL345_REG_MULTI_READ(ALT_I2C_DEV_t *i2c_dev, uint8_t readaddr,uint8_t readdata[], uint8_t len){
    bool bSuccess = false;
    
    if (alt_i2c_issue_write(i2c_dev, readaddr, false, false) == ALT_E_SUCCESS) {
        if (alt_i2c_master_receive(i2c_dev, readdata, len, false, true) == ALT_E_SUCCESS) {
            bSuccess = true;
        }
    }
    return bSuccess;
}

bool ADXL345_Init(ALT_I2C_DEV_t *i2c_dev){
    bool bSuccess;
    
   
    // +- 2g range, 10 bits
    bSuccess = ADXL345_REG_WRITE(i2c_dev, ADXL345_REG_DATA_FORMAT, XL345_RANGE_2G | XL345_FULL_RESOLUTION);
 
        
    //Output Data Rate: 50Hz
    if (bSuccess){
        bSuccess = ADXL345_REG_WRITE(i2c_dev, ADXL345_REG_BW_RATE, XL345_RATE_50); // 50 HZ
    }
    
            
        
    //INT_Enable: Data Ready
    if (bSuccess){   
        bSuccess = ADXL345_REG_WRITE(i2c_dev, ADXL345_REG_INT_ENALBE, XL345_DATAREADY);
    }
    
    // stop measure
    if (bSuccess){
        bSuccess = ADXL345_REG_WRITE(i2c_dev, ADXL345_REG_POWER_CTL, XL345_STANDBY);
    }

    // start measure
    if (bSuccess){
        bSuccess = ADXL345_REG_WRITE(i2c_dev, ADXL345_REG_POWER_CTL, XL345_MEASURE);
        
    }
    
            
    return bSuccess;    
        
}


  

bool ADXL345_IsDataReady(ALT_I2C_DEV_t *i2c_dev){
    bool bReady = false;
    uint8_t data8;
    
    if (ADXL345_REG_READ(i2c_dev, ADXL345_REG_INT_SOURCE,&data8)){
        if (data8 & XL345_DATAREADY)
            bReady = true;
    }            
    
    return bReady;
}



bool ADXL345_XYZ_Read(ALT_I2C_DEV_t *i2c_dev, uint16_t szData16[3]){
    bool bPass;
    uint8_t szData8[6];
    bPass = ADXL345_REG_MULTI_READ(i2c_dev, 0x32, (uint8_t *)&szData8, sizeof(szData8));
    if (bPass){
        szData16[0] = (szData8[1] << 8) | szData8[0]; 
        szData16[1] = (szData8[3] << 8) | szData8[2];
        szData16[2] = (szData8[5] << 8) | szData8[4];
    }        
    
    return bPass;
}

bool ADXL345_IdRead(ALT_I2C_DEV_t *i2c_dev, uint8_t *pId){
    bool bPass;
    bPass = ADXL345_REG_READ(i2c_dev, ADXL345_REG_DEVID, pId);
    
    return bPass;
}


