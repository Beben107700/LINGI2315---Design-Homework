#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

#include "alt_clock_manager.h"
#include "alt_generalpurpose_io.h"
#include "alt_globaltmr.h"
#include "alt_interrupt.h"
#include "alt_timers.h"
#include "alt_i2c.h"

#include "socal/alt_gpio.h"
#include "socal/hps.h"
#include "socal/socal.h"

#include "MyApp_Gsensor.h"
#include "ADXL345.h"
#include "hwlib.h"
#include "hps_0.h"

/* Interrupt service routine for the buttons */
void button_isr_callback (uint32_t icciar, void *context)
{
    // Do something
    printf("INFO: IRQ from buttons : %x (edge = %x)\r\n", alt_read_word(fpga_buttons), alt_read_word(fpga_buttons + 12));
    
    //I here add the call to handle what happens when a button was pressed --> code from last homework
    //This was suggested to me by a friend, I would just have put it on the main loop otherwise.
    handle_fpga_buttons();
    // Clear the interrupt
    alt_gpt_int_clear_pending (GPT_BUTTON_IRQ);
    // Clear the interruptmask of PIO core
    alt_write_word(fpga_buttons + (2*4), 0x0);

    // Enable the interruptmask and edge register of PIO core for new interrupt
    alt_write_word(fpga_buttons + (2*4), 0x3);
    alt_write_word(fpga_buttons + (3*4), 0x3);
}

void sw_isr_callback (uint32_t icciar, void *context)
{
    // Do something
    printf("INFO: IRQ from switchh");

    //I here add the call to handle what happens when a button was pressed --> code from last homework
    //This was suggested to me by a friend, I would just have put it on the main loop otherwise.
    read_switches();
    // Clear the interrupt
    alt_gpt_int_clear_pending (GPT_SW_IRQ);
    // Clear the interruptmask of PIO core
    alt_write_word(fpga_switches + (2*4), 0x0);

    // Enable the interruptmask and edge register of PIO core for new interrupt
    alt_write_word(fpga_switches + (2*4), 0xf);
    alt_write_word(fpga_switches + (3*4), 0xf);
}

/* Interrupt service routine for the timer */
void timer_isr_callback (uint32_t icciar, void *context)
{
    // Clear the interrupt
    alt_gpt_int_clear_pending (GPT_TIMER_ID);
    
    // Toggle hps led
    uint32_t hps_led_value = alt_read_word(ALT_GPIO1_SWPORTA_DR_ADDR);
    hps_led_value >>= HPS_LED_PORT_BIT;
    hps_led_value = !hps_led_value;
    hps_led_value <<= HPS_LED_PORT_BIT;
    assert(ALT_E_SUCCESS == alt_gpio_port_data_write(HPS_LED_PORT, HPS_LED_MASK, hps_led_value));
}

void setup_hps_interrupt() {
    
    // Initialize global interrupts
    assert(ALT_E_SUCCESS == alt_int_global_init());
    // Initialize CPU interrupts
    assert(ALT_E_SUCCESS == alt_int_cpu_init());
    // Register timer ISR
    assert(ALT_E_SUCCESS == alt_int_isr_register(GPT_TIMER_IRQ, timer_isr_callback, NULL));
    // Ignore target_set() for non-SPI interrupts
    if (GPT_TIMER_IRQ >= 32) {
        // Set timer interrupt distributor target (=0x3) (1 = CPU0, 2=CPU1)
        assert(ALT_E_SUCCESS == alt_int_dist_target_set (GPT_TIMER_IRQ, (1 << alt_int_util_cpu_count()) - 1));
    }
    // Enable distributor interrupt
    assert(ALT_E_SUCCESS == alt_int_dist_enable(GPT_TIMER_IRQ));
    
    // Register button ISR
    assert(ALT_E_SUCCESS == alt_int_isr_register(GPT_BUTTON_IRQ, button_isr_callback, NULL));
    // Ignore target_set() for non-SPI interrupts
    if ((ALT_INT_INTERRUPT_F2S_FPGA_IRQ0 + BUTTON_PIO_IRQ) >= 32) {
        // Set timer interrupt distributor target (=0x3) (1 = CPU0, 2=CPU1)
        assert(ALT_E_SUCCESS == alt_int_dist_target_set (GPT_BUTTON_IRQ, (1 << alt_int_util_cpu_count()) - 1));
    }
    // Enable distributor interrupt
    assert(ALT_E_SUCCESS == alt_int_dist_enable(GPT_BUTTON_IRQ));
    // Enable interruptmask and edgecapture of PIO core for buttons 0 and 1
    alt_write_word(fpga_buttons + (2*4), 0x3);
    alt_write_word(fpga_buttons + (3*4), 0x3);


    //SWITCH INTERRUPT
    assert(ALT_E_SUCCESS == alt_int_isr_register(GPT_SW_IRQ, sw_isr_callback , NULL));

    // Ignore target_set() for non-SPI interrupts
    if ((ALT_INT_INTERRUPT_F2S_FPGA_IRQ0 + DIPSW_PIO_IRQ) >= 32) {
        // Set timer interrupt distributor target (=0x3) (1 = CPU0, 2=CPU1)
        assert(ALT_E_SUCCESS == alt_int_dist_target_set (GPT_SW_IRQ, (1 << alt_int_util_cpu_count()) - 1));
    }
    // Enable distributor interrupt
    assert(ALT_E_SUCCESS == alt_int_dist_enable(GPT_SW_IRQ));
    alt_write_word(fpga_switches + (2*4), 0xf);
    alt_write_word(fpga_switches + (3*4), 0xf);
    

    // Enable CPU interrupts
    assert(ALT_E_SUCCESS == alt_int_cpu_enable());
    // Enable all non-secure interrupt
    assert(ALT_E_SUCCESS == alt_int_cpu_enable_ns());
    // Enable global interrupts
    assert(ALT_E_SUCCESS == alt_int_global_enable());
}

void setup_hps_timer() {
    
    // Initialize global timer
    assert(ALT_E_SUCCESS == alt_globaltmr_init());

    // Determine the frequency of the timer
    uint32_t freq;
    uint32_t period_in_ms = 500;
    assert(ALT_E_SUCCESS == alt_clk_freq_get(ALT_CLK_MPU_PERIPH, &freq));
    uint32_t counter = (freq / 1000) * period_in_ms;
    assert(ALT_E_SUCCESS == alt_gpt_counter_set(GPT_TIMER_ID, counter));

    printf("INFO: Frequency = %" PRIu32 ".\r\n", freq);
    printf("INFO: Period    = %" PRIu32 " millisecond(s).\r\n", period_in_ms);
    printf("INFO: Counter   = %" PRIu32 ".\r\n", counter);
    printf("INFO: Check     = %" PRIu32 " microsecond(s).\r\n", alt_gpt_time_microsecs_get(GPT_TIMER_ID));

    // Set to periodic, meaning it fires repeatedly
    assert(ALT_E_SUCCESS == alt_gpt_mode_set(GPT_TIMER_ID, ALT_GPT_RESTART_MODE_PERIODIC));
    // Set the prescaler of the timer to 0
    assert(ALT_E_SUCCESS == alt_gpt_prescaler_set(GPT_TIMER_ID, 0));
    // Clear pending interrupts
    assert(ALT_E_SUCCESS == alt_gpt_int_if_pending_clear(GPT_TIMER_ID));
    // Enable timer interrupts
    assert(ALT_E_SUCCESS == alt_gpt_int_enable(GPT_TIMER_ID));
    // Start the timer
    assert(ALT_E_SUCCESS == alt_gpt_tmr_start(GPT_TIMER_ID));
}

void setup_hps_gpio() {
    uint32_t hps_gpio_config_len = 2;
    ALT_GPIO_CONFIG_RECORD_t hps_gpio_config[] = {
        {HPS_LED_IDX  , ALT_GPIO_PIN_OUTPUT, 0, 0, ALT_GPIO_PIN_DEBOUNCE, ALT_GPIO_PIN_DATAZERO},
        {HPS_KEY_N_IDX, ALT_GPIO_PIN_INPUT , 0, 0, ALT_GPIO_PIN_DEBOUNCE, ALT_GPIO_PIN_DATAZERO}
    };

    assert(ALT_E_SUCCESS == alt_gpio_init());
    assert(ALT_E_SUCCESS == alt_gpio_group_config(hps_gpio_config, hps_gpio_config_len));
}

void setup_hps_i2c() {
    
    uint32_t target_addr = 0b01010011; // I2C address of ADXL345 is 0x53
    uint8_t  id;
    
    assert(ALT_E_SUCCESS == alt_i2c_init(ALT_I2C_I2C0, &i2c_dev));
    assert(ALT_E_SUCCESS == alt_i2c_op_mode_set(&i2c_dev, ALT_I2C_MODE_MASTER));
    assert(ALT_E_SUCCESS == alt_i2c_master_target_set(&i2c_dev, target_addr));
    assert(ALT_E_SUCCESS == alt_i2c_enable(&i2c_dev));

    
    if (ADXL345_Init(&i2c_dev)) {
        if (ADXL345_IdRead(&i2c_dev, &id))
            printf("ADXL345 id = %02Xh\r\n", id);
    }
    
}

void setup_fpga_leds() {
    // Switch on first LED only
    alt_write_word(fpga_leds, 0x1);
}

/* The HPS doesn't have a sleep() function like the Nios II, so we can make one
 * by using the global timer. */
void delay_us(uint32_t us) {
    uint64_t start_time = alt_globaltmr_get64();
    uint32_t timer_prescaler = alt_globaltmr_prescaler_get() + 1;
    uint64_t end_time;
    alt_freq_t timer_clock;

    assert(ALT_E_SUCCESS == alt_clk_freq_get(ALT_CLK_MPU_PERIPH, &timer_clock));
    end_time = start_time + us * ((timer_clock / timer_prescaler) / ALT_MICROSECS_IN_A_SEC);

    // polling wait
    while(alt_globaltmr_get64() < end_time);
}

void handle_hps_led() {
    uint32_t hps_gpio_input = alt_gpio_port_data_read(HPS_KEY_N_PORT, HPS_KEY_N_MASK);

    // HPS_KEY_N is active-low
    bool toggle_hps_led = (~hps_gpio_input & HPS_KEY_N_MASK);

    if (toggle_hps_led) {
    	alt_write_word(fpga_leds, 0x3);    }
}

void handle_fpga_leds() {
    uint32_t leds_mask = alt_read_word(fpga_leds);

    if (leds_mask != (0x01 << (LED_PIO_DATA_WIDTH - 1))) {
        // rotate leds
        leds_mask <<= 1;
    } else {
        // reset leds
        leds_mask = 0x1;
    }

    alt_write_word(fpga_leds, leds_mask);
}

void print_on_leds(int sensoroutput){

	int32_t led_mask=alt_read_word(fpga_leds);
	int16_t reading = sensoroutput;

	if(reading <=0) reading = -reading;
	reading=(int16_t)reading/300;

	switch(reading){

	case 0:
		led_mask = 0x0;
		break;
	case 1:
		led_mask = 0x1;
		break;
	case 2:
		led_mask = 0x3;
		break;
	case 3:
		led_mask = 0x7;
		break;
	case 4:
		led_mask = 0xf;
		break;
	case 5:
		led_mask = 0x1f;
		break;
	case 6:
		led_mask = 0x3f;
		break;
	case 7:
		led_mask = 0x7f;
		break;

	default:
		break;


	}
	alt_write_word(fpga_leds, led_mask);


}


int handle_gsensor(int axis) {
    bool bSuccess;
    const int mg_per_digi = 4;
    uint16_t szXYZ[3];
    
    if (ADXL345_IsDataReady(&i2c_dev)){
        bSuccess = ADXL345_XYZ_Read(&i2c_dev, szXYZ);
        if (bSuccess){
            printf("X=%d mg, Y=%d mg, Z=%d mg\r\n",(int16_t)szXYZ[0]*mg_per_digi, (int16_t)szXYZ[1]*mg_per_digi, (int16_t)szXYZ[2]*mg_per_digi);
            // show raw data,
            //printf("X=%04x, Y=%04x, Z=%04x\r\n", (alt_u16)szXYZ[0], (alt_u16)szXYZ[1],(alt_u16)szXYZ[2]);

            axis-=1;
            return (int)szXYZ[axis]*mg_per_digi;
        }
        else return 0;
    }
    return 0;
}
void handle_fpga_buttons(){
	//I just added the code of last homework.
	uint32_t button = alt_read_word(fpga_buttons);
	uint32_t frequency = alt_read_word(fpga_pio_0);

	if (button == 1){
		frequency  += PIO_0_FREQ/10;
		alt_write_word(fpga_pio_0, frequency);
	}
	if (button == 2){
		frequency -= PIO_0_FREQ/10;
		alt_write_word(fpga_pio_0, frequency);
	}
}


void read_switches(){
	uint32_t switchreading = alt_read_word(fpga_switches);

	int switchvalue = (int)(switchreading) % 4;
	if (switchvalue == 0){
		switchvalue = 1;
	}
	current_switch = switchvalue;




}
int main() {
    printf("\r\nDE10-Nano - MyApp_Gsensor\r\n\r\n");

    setup_hps_interrupt();

    setup_hps_timer();
    setup_hps_gpio();
    setup_hps_i2c();
    setup_fpga_leds();
    alt_write_word(fpga_pio_0, 24999999);//Init the default value

    while (true) {
        handle_hps_led();
        //handle_fpga_buttons(); //Removed because is not done often and added in the interruption code.
        //handle_fpga_leds();
      //  read_switches();
    	int toprint = handle_gsensor(current_switch);
    	print_on_leds(toprint);
    	printf("%d", current_switch);
        //handle_gsensor(1);
        delay_us(ALT_MICROSECS_IN_A_SEC/100);
    }

    return 0;
}
