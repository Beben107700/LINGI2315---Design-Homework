/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include <stdlib.h> // malloc, free
#include <string.h>
#include <stddef.h>
#include <unistd.h>  // usleep (unix standard?)
#include "io.h"
#include "alt_types.h"  // alt_u32
#include <sys/alt_cache.h>
#include "system.h"
#include <fcntl.h>
#include "altera_avalon_pio_regs.h"
#include "altera_avalon_spi_regs.h" //Merci Louis

typedef int bool;

#define TRUE    1
#define FALSE   0

int main()
{
    //unsigned int value = 0;
    int serial = 1;

    printf("NIOS Version 13 turns on  \r\n");

    while(1) {
//    	IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_NIOS_BASE, value++);//This is just the led
//
//
//    	if(serial >=128){
//    		serial=1;
//    	}
//    	else{
//    		serial = serial<<1;
//    		IOWR_ALTERA_AVALON_SPI_TXDATA(SPI_NIOS_BASE, serial);
//    	}
      	serial = IORD_ALTERA_AVALON_SPI_RXDATA(SPI_NIOS_BASE);
      	printf("Recieving value in NIOS: %d\n", serial);
    	if(serial<0){
    		serial = -serial;//Absolute value
    	}
    	if(serial<100){
    		IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_NIOS_BASE,0x1);
    	}
    	else if(serial<200){
    		IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_NIOS_BASE,3);
    	}
    	else if(serial<500){
    		IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_NIOS_BASE,15);
    	}
    	else if(serial<700){
    		IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_NIOS_BASE,31);
    	}
    	else if(serial<1000){
    		IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_NIOS_BASE,63);
    	}


    	else{
    		IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_NIOS_BASE,0);
    	}
    	IOWR_8DIRECT(ONCHIP_MEMORY2_0_BASE, 0x20000000,0xFF);
    	IOWR_8DIRECT(ONCHIP_MEMORY2_0_BASE, 0x21000000,0xFF);
    	usleep(500000);//Changed slp time
    }
}
